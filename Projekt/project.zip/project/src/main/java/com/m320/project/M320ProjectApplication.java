package com.m320.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M320ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(M320ProjectApplication.class, args);
	}

}
