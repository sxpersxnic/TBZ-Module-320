package com.m320.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M320ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
